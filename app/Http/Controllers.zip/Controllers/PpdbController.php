<?php

namespace App\Http\Controllers;

use App\Models\Concentration;
use App\Models\PpdbRegistrant;
use App\Models\Program;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;

class PpdbController extends Controller
{
    public function create(Request $request): View
    {
        $programs = Program::with('concentrations')->get();

        // Pre-select program/concentration when arriving from the
        // "Daftar ke Konsentrasi Ini" button on the Program Keahlian page.
        $selectedProgramId = $request->integer('program') ?: null;
        $selectedConcentrationId = $request->integer('concentration') ?: null;

        return view('ppdb.form', compact('programs', 'selectedProgramId', 'selectedConcentrationId'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'full_name' => ['required', 'string', 'max:255'],
            'gender' => ['required', 'in:L,P'],
            'nik' => ['required', 'digits:16'],
            'nisn' => ['required', 'digits_between:8,10'],
            'no_kk' => ['required', 'digits:16'],
            'address' => ['required', 'string'],
            'program_id' => ['required', 'exists:programs,id'],
            'concentration_id' => ['nullable', 'exists:concentrations,id'],
            'has_kip' => ['nullable', 'boolean'],
            'has_kis' => ['nullable', 'boolean'],
            'has_pkh' => ['nullable', 'boolean'],
            // TODO: add 'g-recaptcha-response' => ['required'] once reCAPTCHA is wired up
        ]);

        $registrant = PpdbRegistrant::create([
            ...$validated,
            'has_kip' => $request->boolean('has_kip'),
            'has_kis' => $request->boolean('has_kis'),
            'has_pkh' => $request->boolean('has_pkh'),
            'registration_number' => PpdbRegistrant::generateRegistrationNumber(),
            'status' => 'pending',
        ]);

        return redirect()
            ->route('ppdb.success', $registrant->registration_number)
            ->with('registrant', $registrant);
    }

    public function success(string $registrationNumber): View
    {
        $registrant = PpdbRegistrant::where('registration_number', $registrationNumber)
            ->firstOrFail();

        return view('ppdb.success', compact('registrant'));
    }

    public function checkStatusForm(): View
    {
        return view('ppdb.check-status');
    }

    public function checkStatus(Request $request): View
    {
        $request->validate([
            'registration_number' => ['required', 'string'],
        ]);

        $registrant = PpdbRegistrant::where('registration_number', $request->registration_number)
            ->first();

        return view('ppdb.check-status', compact('registrant'));
    }

    /**
     * AJAX endpoint used by the program -> concentration dependent dropdown
     * on the registration form.
     */
    public function concentrationsByProgram(Program $program)
    {
        return response()->json(
            $program->concentrations()->select('id', 'name')->get()
        );
    }
}
