<?php

namespace App\Http\Controllers;

use App\Models\News;
use App\Models\NewsComment;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class NewsController extends Controller
{
    public function index(): View
    {
        $news = News::published()->latest('published_at')->paginate(9);

        return view('berita.index', compact('news'));
    }

    public function show(News $news): View
    {
        $news->load('approvedComments');

        return view('berita.show', compact('news'));
    }

    /**
     * Comments are never shown immediately — they're saved as 'pending' and
     * only appear on the article after an admin approves them in the
     * Dashboard Admin comment moderation screen.
     */
    public function storeComment(Request $request, News $news): RedirectResponse
    {
        $validated = $request->validate([
            'nama_pengirim' => ['required', 'string', 'max:255'],
            'isi_komentar' => ['required', 'string', 'max:2000'],
            // TODO: add 'g-recaptcha-response' => ['required'] once reCAPTCHA is wired up
        ]);

        NewsComment::create([
            'news_id' => $news->id,
            'nama_pengirim' => $validated['nama_pengirim'],
            'isi_komentar' => $validated['isi_komentar'],
            'status' => 'pending',
        ]);

        return back()->with('success', 'Komentar Anda sedang menunggu persetujuan admin.');
    }
}
