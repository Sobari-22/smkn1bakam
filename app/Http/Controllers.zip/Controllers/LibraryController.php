<?php

namespace App\Http\Controllers;

use App\Models\LibraryBook;
use App\Models\Page;
use Illuminate\Http\Request;
use Illuminate\View\View;

class LibraryController extends Controller
{
    public function index(Request $request): View
    {
        $query = LibraryBook::query()
            ->select('id', 'no_induk_buku', 'judul', 'pengarang', 'jumlah'); // publik: field terbatas

        if ($search = $request->get('q')) {
            $query->where(function ($q) use ($search) {
                $q->where('judul', 'like', "%{$search}%")
                    ->orWhere('pengarang', 'like', "%{$search}%");
            });
        }

        $books = $query->orderBy('judul')->paginate(12)->withQueryString();

        $libraryProfile = Page::where('slug', 'tentang-perpustakaan')->first();

        return view('elibrary.index', compact('books', 'libraryProfile'));
    }
}
