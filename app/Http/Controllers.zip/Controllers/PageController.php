<?php

namespace App\Http\Controllers;

use App\Models\Program;
use Illuminate\View\View;

/**
 * Handles simple static/public pages. Each of these views is a stub for now
 * (resources/views/*.blade.php) — build out the real content per page next,
 * following the same layout as home.blade.php.
 */
class PageController extends Controller
{
    public function profil(): View
    {
        return view('profil');
    }

    public function program(): View
    {
        // Design shows all programs + their concentrations on a single page
        // (with a detail modal per concentration), not separate pages per
        // program — so program.show below is kept only for a possible
        // future direct-link use case, not linked from this page.
        $programs = Program::with('concentrations')->get();

        return view('program.index', compact('programs'));
    }

    public function programShow(Program $program): View
    {
        $program->load('concentrations', 'teachers');

        return view('program.show', compact('program'));
    }

    public function galeri(): View
    {
        return view('galeri');
    }

    public function kontak(): View
    {
        return view('kontak');
    }

    public function bkk(): View
    {
        return view('bkk');
    }
}
